(function(){
'use strict';
window.addEventListener('message', function(event){
  if(!event.data || event.data.type!=='yekan-vt612-height')return;
  document.querySelectorAll('iframe.yekan-vt612-frame').forEach(function(frame){
    if(frame.contentWindow!==event.source)return;
    const h=Number(event.data.height);
    if(Number.isFinite(h)&&h>0&&h<50000)frame.style.height=Math.ceil(h+8)+'px';
  });
});
})();

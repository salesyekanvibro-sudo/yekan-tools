(function () {
  'use strict';
  const entries = Object.entries(window.YekanTextOverrides || {}).filter(([a,b]) => a && a !== b);
  entries.sort((a,b) => b[0].length-a[0].length);
  const mapping = new Map(entries);
  const escape = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = entries.length ? new RegExp(entries.map(([s]) => escape(s)).join('|'), 'gu') : null;
  const rendered = new WeakMap();
  function replace(s) { return pattern ? s.replace(pattern, key => mapping.get(key)) : s; }
  function apply() {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (node.parentElement.closest('script,style')) continue;
      if (rendered.get(node) === node.nodeValue) continue;
      const value = replace(node.nodeValue);
      rendered.set(node, value);
      if (value !== node.nodeValue) node.nodeValue = value;
    }
    document.querySelectorAll('[placeholder],[title],[aria-label]').forEach(el => {
      for (const a of ['placeholder','title','aria-label']) {
        const key = 'data-yk-original-' + a;
        if (!el.hasAttribute(a)) continue;
        if (!el.hasAttribute(key)) el.setAttribute(key, el.getAttribute(a));
        const value = replace(el.getAttribute(key));
        if (value !== el.getAttribute(a)) el.setAttribute(a,value);
      }
    });
  }
  function resize() {
    parent.postMessage({type:'yekan-vt612-height',height:Math.ceil(document.body.getBoundingClientRect().height)}, '*');
  }
  function start() {
    const style=document.createElement('style');
    style.textContent='html,body{margin:0;padding:0}html{overflow-y:hidden}';
    document.head.appendChild(style);
    apply();
    new MutationObserver(() => { apply(); resize(); }).observe(document.body,{subtree:true,childList:true,characterData:true});
    new ResizeObserver(resize).observe(document.body);
    window.addEventListener('resize',resize);
    resize();
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start);
  else start();
})();

(function(){
'use strict';
const form=document.getElementById('yk-form');
if(!form)return;
const rows=document.getElementById('yk-rows');
document.getElementById('yk-search').addEventListener('input',function(){
  const q=this.value.toLocaleLowerCase();
  rows.querySelectorAll('tr').forEach(row=>{row.hidden=!(row.querySelector('.yk-original').textContent+' '+row.querySelector('textarea').value).toLocaleLowerCase().includes(q);});
});
document.getElementById('yk-add').addEventListener('click',function(){
  const a=document.getElementById('yk-new-original'),b=document.getElementById('yk-new-value');
  if(!a.value.trim())return;
  const tr=document.createElement('tr'),left=document.createElement('td'),right=document.createElement('td'),input=document.createElement('textarea');
  left.className='yk-original';left.textContent=a.value;
  input.className='yk-value';input.value=b.value;input.rows=3;input.dir='auto';input.style.width='100%';
  right.appendChild(input);tr.append(left,right);rows.appendChild(tr);a.value='';b.value='';
});
document.getElementById('yk-reset').addEventListener('click',function(e){if(!confirm('همه متن‌های ویرایش‌شده به نسخه اصلی برگردند؟'))e.preventDefault();});
form.addEventListener('submit',function(){
  const changes=Object.create(null);
  rows.querySelectorAll('tr').forEach(row=>{
    const original=row.querySelector('.yk-original').textContent,value=row.querySelector('textarea').value;
    if(original!==value)changes[original]=value;
  });
  document.getElementById('yk-changes').value=JSON.stringify(changes);
});
})();

<?php
/**
 * Plugin Name: Yekan VT612 Editable
 * Description: ابزار دوزبانه VT612 با ویرایش متن‌ها و شورت‌کد [yekan_vt612].
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Yekan
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) { exit; }

function yekan_vt612_catalog() {
    return json_decode(file_get_contents(__DIR__ . '/texts.json'), true) ?: array();
}
function yekan_vt612_overrides() {
    $value = get_option('yekan_vt612_texts', array());
    return is_array($value) ? $value : array();
}
add_action('admin_menu', function () {
    add_options_page('متن‌های ابزار یکان', 'متن‌های ابزار یکان', 'manage_options', 'yekan-vt612', 'yekan_vt612_admin');
});
function yekan_vt612_admin() {
    if (!current_user_can('manage_options')) { return; }
    $catalog = yekan_vt612_catalog();
    $overrides = yekan_vt612_overrides();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        check_admin_referer('yekan_vt612_save');
        if (isset($_POST['reset'])) {
            delete_option('yekan_vt612_texts');
            $overrides = array();
        } elseif (isset($_POST['changes'])) {
            // A single JSON field avoids PHP max_input_vars truncation.
            $changes = json_decode(wp_unslash($_POST['changes']), true);
            if (!is_array($changes)) {
                echo '<div class="notice notice-error"><p>اطلاعات ذخیره نشد؛ صفحه را تازه کنید و دوباره تلاش کنید.</p></div>';
            } else {
                $clean = array();
                foreach ($changes as $original => $replacement) {
                    if (!is_string($original) || !is_string($replacement) || $original === '') { continue; }
                    $original = sanitize_textarea_field($original);
                    $replacement = sanitize_textarea_field($replacement);
                    if ($original !== '' && $original !== $replacement) { $clean[$original] = $replacement; }
                }
                update_option('yekan_vt612_texts', $clean, false);
                $overrides = $clean;
                echo '<div class="notice notice-success"><p>متن‌ها ذخیره شدند. در صورت استفاده از کش، کش برگه را پاک کنید.</p></div>';
            }
        }
    }
    $all = array_unique(array_merge($catalog, array_keys($overrides)));
    echo '<div class="wrap" dir="rtl"><h1>ویرایش متن‌های ابزار یکان VT612</h1><p>شورت‌کد برگه: <code>[yekan_vt612]</code></p><p>متن‌های فارسی و انگلیسی مستقل هستند. متن اصلی را در سمت راست پیدا کنید و جایگزین دلخواه را بنویسید. HTML اجرا نمی‌شود. خالی گذاشتن یک کادر، آن متن را پنهان می‌کند.</p><p>این تغییرات فقط نوشته‌ها را عوض می‌کنند؛ فرمول‌ها و حدود عددی ابزار ثابت می‌مانند.</p><label>جست‌وجوی متن <input id="yk-search" type="search" style="width:60%"></label><form method="post" id="yk-form">';
    wp_nonce_field('yekan_vt612_save');
    echo '<input type="hidden" name="changes" id="yk-changes"><table class="widefat striped"><thead><tr><th>متن اصلی</th><th>متن دلخواه شما</th></tr></thead><tbody id="yk-rows">';
    foreach ($all as $original) {
        $value = array_key_exists($original, $overrides) ? $overrides[$original] : $original;
        echo '<tr><td style="width:45%;white-space:pre-wrap" class="yk-original">' . esc_html($original) . '</td><td><textarea class="yk-value" rows="3" dir="auto" style="width:100%">' . esc_textarea($value) . '</textarea></td></tr>';
    }
    echo '</tbody></table><p>متنی پیدا نشد؟ عین عبارت نمایش‌داده‌شده را از صفحه کپی و یک ردیف اضافه کنید. عبارت طولانی‌تر اولویت دارد و همه موارد یکسان با هم تغییر می‌کنند.</p><p><textarea id="yk-new-original" placeholder="متن فعلی" dir="auto"></textarea> <textarea id="yk-new-value" placeholder="متن جدید" dir="auto"></textarea> <button type="button" class="button" id="yk-add">افزودن ردیف</button></p><p><button class="button button-primary" type="submit">ذخیره همه تغییرات</button> <button class="button" type="submit" name="reset" value="1" id="yk-reset">بازگشت همه متن‌ها به نسخه اصلی</button></p></form></div>';
    wp_enqueue_script('yekan-vt612-admin', plugins_url('admin.js', __FILE__), array(), '1.0.0', true);
}
add_shortcode('yekan_vt612', function () {
    $html = file_get_contents(__DIR__ . '/page.html');
    $map = wp_json_encode(yekan_vt612_overrides(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_FORCE_OBJECT);
    $runtime = file_get_contents(__DIR__ . '/editor-runtime.js');
    $html = str_replace('</body>', '<script>window.YekanTextOverrides=' . $map . ';' . $runtime . '</script></body>', $html);
    wp_enqueue_script('yekan-vt612-frame', plugins_url('frame.js', __FILE__), array(), '1.0.0', true);
    return '<iframe class="yekan-vt612-frame" title="ابزار انتخاب رنج VT612" sandbox="allow-scripts allow-modals" style="display:block;width:100%;height:1600px;border:0" srcdoc="' . esc_attr($html) . '"></iframe>';
});
